

<?php $__env->startSection('title', 'Detail Sesi: ' . $sesi_absensi->nama); ?>
<?php $__env->startSection('page', 'Detail Sesi Absensi'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3><?php echo e($sesi_absensi->nama); ?></h3>
            <p class="text-muted mb-0">Kegiatan: <?php echo e($kegiatan->nama); ?></p>
        </div>
        <a href="<?php echo e(route('operator.kegiatan.detail', $kegiatan->id)); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Kembali ke Detail Kegiatan
        </a>
    </div>

    
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Total Peserta</h5>
                    <h2><?php echo e($statistik['totalPeserta']); ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Sudah Hadir</h5>
                    <h2 class="text-success"><?php echo e($statistik['jumlahHadir']); ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Belum Hadir</h5>
                    <h2 class="text-danger"><?php echo e($statistik['jumlahBelumHadir']); ?></h2>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row mb-4">
        
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="bi bi-check-circle-fill"></i> Peserta Sudah Hadir</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped datatable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Peserta</th>
                                <th>NIM</th>
                                <th>kelompok</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pesertaHadir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($peserta->nama); ?></td>
                                <td><?php echo e($peserta->nim ?? '-'); ?></td>
                                <td><?php echo e($peserta->kelompok ?? '-'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0"><i class="bi bi-x-circle-fill"></i> Peserta Belum Hadir</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped datatable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Peserta</th>
                                <th>NIM</th>
                                <th>Kelompok</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pesertaBelumHadir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($peserta->nama); ?></td>
                                <td><?php echo e($peserta->nim ?? '-'); ?></td>
                                <td><?php echo e($peserta->kelompok ?? '-'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


<script>
    $(document).ready(function() {
        $('.datatable').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.21/i18n/Indonesian.json"
            },
            "responsive": true
        });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\absensi\resources\views/operator/absensiShow.blade.php ENDPATH**/ ?>