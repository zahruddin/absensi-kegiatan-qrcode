<h3>Struk Pembayaran</h3>
<p>Tanggal: <?php echo e($sale->created_at->format('d-m-Y H:i')); ?></p>
<p>Meja: <?php echo e($sale->meja->nama_meja ?? '-'); ?></p>

<table>
    <thead>
        <tr>
            <th>Produk</th>
            <th>Harga</th>
            <th>Jumlah</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $sale->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->nama_produk); ?></td>
            <td>Rp <?php echo e(number_format($item->harga_produk, 0, ',', '.')); ?></td>
            <td><?php echo e($item->jumlah); ?></td>
            <td>Rp <?php echo e(number_format($item->total, 0, ',', '.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<p><strong>Total Bayar:</strong> Rp <?php echo e(number_format($sale->total_bayar, 0, ',', '.')); ?></p>
<?php /**PATH C:\laragon\www\cafe-ordering-app\resources\views/kasir/struk.blade.php ENDPATH**/ ?>